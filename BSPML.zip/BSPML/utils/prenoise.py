import random

import numpy as np
def noise(dataset,ratio,seed):
    np.random.seed(seed)
    label_all = np.array(dataset.real_labels)
    num_noise=int(len(label_all)*ratio)
    num_class_all = len(np.unique(label_all))
    num_instant_eachclass = np.zeros(num_class_all, dtype='int')
    for pid in label_all:
        num_instant_eachclass[pid] += 1
    idex_noise=np.array([],dtype='int')
    start=0
    end=num_instant_eachclass[0]
    num_instant_eachclass_noise=[]
    for item in range(len(num_instant_eachclass)):
        if num_noise<=0:
            break
        if item>0:
            start+=num_instant_eachclass[item-1]
            end+=num_instant_eachclass[item]
        num_idex_item=max(1,round(ratio * num_instant_eachclass[item]))
        num_noise=num_noise-num_idex_item
        num_instant_eachclass_noise.append(num_idex_item)
        idex_item = random.sample(range(start, end), num_idex_item)
        idex_item = np.array(idex_item)
        idex_noise = np.concatenate((idex_noise, idex_item))
    idex_noise=np.sort(idex_noise)
    label_noise=np.array([],dtype='int')
    for item in range(len(num_instant_eachclass_noise)):
        label_noise_item=np.ones((num_instant_eachclass_noise[item]),dtype='int')*item
        label_noise=np.concatenate((label_noise,label_noise_item))
    label_noise=label_noise[::-1]
    for item in range(len(idex_noise)):
        idex=idex_noise[item]
        label=label_noise[item]
        dataset.real_labels[idex]=label
        dataset.labels[idex] = label
    label_sort=np.argsort(dataset.real_labels)
    dataset.real_labels=dataset.real_labels[label_sort]
    dataset.labels=dataset.labels[label_sort]
    dataset.real_img_paths=np.array(dataset.real_img_paths)[label_sort].tolist()
    dataset.img_paths=np.array(dataset.img_paths)[label_sort].tolist()
    return dataset