
from PIL import Image
class Preprocessor(object):
    def __init__(self, dataset,real=False,weight=None):
        super(Preprocessor, self).__init__()
        if real:
            self.dataset = dataset.real_img_paths
            self.labels = dataset.real_labels
            self.transform=dataset.real_transform
        else:
            self.dataset = dataset.img_paths
            self.labels = dataset.labels
            self.transform = dataset.transform
        self.weight=weight

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, indices):
        if isinstance(indices, (tuple, list)):
            return [self._get_single_item(index) for index in indices]
        return self._get_single_item(indices)

    def _get_single_item(self, index):
        fpath = self.dataset[index]
        img = Image.open(fpath).convert('RGB')
        if self.transform is not None:
            img = self.transform(img)
        if self.weight is None:
            return (img,self.labels[index])
        else:
            return (img,self.labels[index],self.weight[index])