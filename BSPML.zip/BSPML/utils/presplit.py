import copy

from utils.pretransformer import PreTransformer
import numpy as np

def split_dataset(dataset,ratio):
    pretransformer = PreTransformer()
    train_transform = pretransformer.train_transform
    test_transform=pretransformer.test_transform
    num_label=len(np.unique(dataset.labels))
    num_label_train=max(1,int(num_label*(1-ratio)))
    idx_test=np.where(dataset.labels==num_label_train)[0][0]

    train_dataset=copy.deepcopy(dataset)
    train_dataset.img_paths=train_dataset.img_paths[:idx_test]
    train_dataset.labels = train_dataset.labels[:idx_test]
    train_dataset.real_img_paths=train_dataset.real_img_paths[:idx_test]
    train_dataset.real_labels = train_dataset.real_labels[:idx_test]
    train_dataset.transform=train_transform
    train_dataset.real_transform=test_transform

    val_dataset = copy.deepcopy(dataset)
    val_dataset.img_paths = val_dataset.img_paths[:idx_test]
    val_dataset.labels = val_dataset.labels[:idx_test]
    val_dataset.transform = test_transform
    val_dataset.real_img_paths = None
    val_dataset.real_labels = None
    val_dataset.real_transform = None

    test_dataset = copy.deepcopy(dataset)
    test_dataset.img_paths = test_dataset.img_paths[idx_test:]
    test_dataset.labels = test_dataset.labels[idx_test:] - num_label_train
    test_dataset.transform = test_transform
    test_dataset.real_img_paths = None
    test_dataset.real_labels = None
    test_dataset.real_transform = None

    return train_dataset,test_dataset,val_dataset
