# -*- coding: utf-8 -*-

import torchvision
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
from utils import *
from torch.autograd import Variable


class f_model(nn.Module):
    def __init__(self,num_features,num_classes,dropout):
        super(f_model, self).__init__()
        self.backbone = torchvision.models.resnet50(pretrained=True)
        state_dict = self.backbone.state_dict()
        out_planes = self.backbone.fc.in_features
        self.backbone = nn.Sequential(*list(self.backbone.children())[:-2])
        model_dict = self.backbone.state_dict()
        model_dict.update({k: v for k, v in state_dict.items() if k in model_dict})
        self.backbone.load_state_dict(model_dict)

        self.drop = nn.Dropout(dropout)

        self.classifier = nn.Linear(out_planes, num_classes)
        init.normal_(self.classifier.weight, std=0.001)
        init.constant_(self.classifier.bias, 0)


    def forward(self, x):
        x = self.backbone(x)
        x = F.avg_pool2d(x, x.size()[2:])
        x = x.view(x.size(0), -1)
        x = self.drop(x)
        x = self.classifier(x)
        return x