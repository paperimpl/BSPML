from pytorch_metric_learning.utils import stat_utils
import numpy as np

def recall(k,query, reference, query_labels, reference_labels, embeddings_come_from_same_source):
    knn_indices, knn_distances = stat_utils.get_knn(reference, query, k, embeddings_come_from_same_source)
    knn_labels = reference_labels[knn_indices]
    knn_bool=(knn_labels==query_labels.reshape(-1,1))
    n,m=knn_bool.shape
    recall_bool=np.ones((n,m))
    for i in range(n):
        for j in range(m):
            if knn_bool[i][j]==False:
                recall_bool[i][j]=0
            else:
                break
    recall_k=np.array([sum(recall_bool[:,j]) for j in range(m)])/n
    return recall_k
