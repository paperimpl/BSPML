
import argparse
import math
import os.path as osp
import random
import time
import multiprocessing
import numpy as np
import threading

import torch
import time
from scipy.optimize import minimize
import os
from torch.autograd import Variable
from sklearn import metrics
import multiprocessing
from multiprocessing.managers import SharedMemoryManager
from numba import njit
from torch.utils.data import DataLoader

from utils.preprocessor import Preprocessor


def cal_pairwise_distance_all(feature_all,label_all,num_instant_eachclass,pairDis_All):
    (num_class_all, num_instant_maxclass, num_class_all, num_instant_maxclass)=pairDis_All[0]
    feature_size=np.shape(feature_all)[1]
    feature_all_new=np.zeros((num_class_all,num_instant_maxclass,feature_size))
    feature_index=np.zeros(num_class_all,dtype='int')
    for item in range(len(label_all)):
        class_item=label_all[item]
        feature_all_new[class_item,feature_index[class_item],:]=feature_all[item,:]
        feature_index[class_item]=feature_index[class_item]+1
    feature_all=feature_all_new
    pool = multiprocessing.Pool(processes=20)
    for i in range(20):
        mean = int(num_class_all / 20) + 1
        list = range(mean * i, min(mean * (i + 1),num_class_all))
        pool.apply_async(AsyPair, (feature_all,num_instant_eachclass,pairDis_All,list))
    pool.close()
    pool.join()

def AsyPair(feature_all,num_instant_eachclass,pairDis_All,list):
    try:
        (num_class_all, num_instant_maxclass, num_class_all, num_instant_maxclass) = pairDis_All[0]
        pairDis = np.ndarray(shape=pairDis_All[0], dtype=pairDis_All[1],buffer=pairDis_All[2].buf)
        for class_first in list:
            if class_first >= num_class_all: continue
            for instant_first in range(num_instant_eachclass[class_first]):
                for class_second in range(num_class_all):
                    for instant_second in range(num_instant_eachclass[class_second]):
                        pairDis[class_first][instant_first][class_second][instant_second]= \
                            njitPair(feature_all[class_first,instant_first,:],feature_all[class_second,instant_second,:])
    except Exception as ex:
        print(str(ex))

@njit
def njitPair(a,b):
    ab=np.dot(a,b)
    a=np.linalg.norm(a)
    b=np.linalg.norm(b)
    return ab/(a*b)

def cal_MSLossArray_all(pairDis_All, MS_Loss_p_All,MS_Loss_n_All, num_instant_eachclass, alpha, beta, base):
    (num_class_all, num_instant_maxclass, num_class_all, num_instant_maxclass)=pairDis_All[0]
    pool = multiprocessing.Pool(processes=20)
    #AsyMS(pairDis_All, MS_Loss_p_All,MS_Loss_n_All,range(num_class_all),num_instant_eachclass,alpha,beta, base)
    for i in range(20):
        mean = int(num_class_all / 20) + 1
        list = range(mean * i, min(num_class_all,mean * (i + 1)))
        pool.apply_async(AsyMS, (pairDis_All, MS_Loss_p_All,MS_Loss_n_All,list,num_instant_eachclass,alpha,beta, base))
    pool.close()
    pool.join()




def AsyMS(pairDis_All, MS_Loss_p_All,MS_Loss_n_All,list,num_instant_eachclass,alpha, beta, base):
    try:
        (num_class_all, num_instant_maxclass) = MS_Loss_n_All[0]
        pairDis = np.ndarray(shape=pairDis_All[0], dtype=pairDis_All[1],buffer=pairDis_All[2].buf)
        MS_Loss_p = np.ndarray(shape=MS_Loss_p_All[0], dtype=MS_Loss_p_All[1], buffer=MS_Loss_p_All[2].buf)
        MS_Loss_n = np.ndarray(shape=MS_Loss_n_All[0], dtype=MS_Loss_n_All[1], buffer=MS_Loss_n_All[2].buf)
        for a_class in list:
            if a_class >=num_class_all: continue
            for a_instant in range(num_instant_eachclass[a_class]):
                MS_Loss_p_only = 0
                MS_Loss_n_only = 0
                for class_only in range(num_class_all):
                    if class_only==a_class:
                        for instant_only in range(num_instant_eachclass[class_only]):
                            if instant_only==a_instant: continue
                            MS_Loss_p_only = njitMS_p(MS_Loss_p_only,
                                                      pairDis[a_class, a_instant, class_only, instant_only], alpha,
                                                      base)
                    else:
                        for instant_only in range(num_instant_eachclass[class_only]):
                            MS_Loss_n_only = njitMS_n(MS_Loss_n_only,
                                                      pairDis[a_class, a_instant, class_only, instant_only], beta,
                                                      base)
                MS_Loss_p[a_class,a_instant]=MS_Loss_p_only
                MS_Loss_n[a_class,a_instant]=MS_Loss_n_only
    except Exception as ex:
        print(str(ex))

@njit
def njitMS_p(MS_Loss_p_only,pairDis,alpha,base):
    return MS_Loss_p_only+math.exp(-alpha*(pairDis-base))

@njit
def njitMS_n(MS_Loss_n_only,pairDis,beta,base):
    return MS_Loss_n_only+math.exp(beta*(pairDis-base))


def indexof(labels,label):
    for index,item in enumerate(labels):
        if int(item)==int(label):
            return index





def UpdateW(model,device,train_dataset,batch_size,lamb,alpha, beta, base,highest,lowest):
    train_real_loader = DataLoader(Preprocessor(train_dataset,True), batch_size=batch_size, drop_last=False)
    model.eval()
    with torch.no_grad():
        train_real_embeddings = torch.Tensor([]).cpu()
        for batch_idx, (data, labels) in enumerate(train_real_loader):
            data, labels = data.to(device), labels.to(device)
            embeddings = model(data)
            train_real_embeddings = torch.cat((train_real_embeddings, embeddings.cpu()), dim=0)
        train_real_embeddings = train_real_embeddings.cpu().detach().numpy()
        label_all = np.array(train_dataset.real_labels)
        feature_all = train_real_embeddings
        num_class_all=len(np.unique(label_all))
        num_instant_eachclass = np.zeros(num_class_all, dtype='int')
        for pid in label_all:
            num_instant_eachclass[pid] += 1
        num_instant_maxclass = max(num_instant_eachclass)
        smm = SharedMemoryManager()
        smm.start()
        #
        pairDis_shape = (num_class_all, num_instant_maxclass, num_class_all, num_instant_maxclass)
        pairDis_dtype = 'float64'  # 2 bt
        pairDis_nbytes = num_class_all * num_instant_maxclass * num_class_all * num_instant_maxclass * 8
        shm_pairDis = smm.SharedMemory(size=pairDis_nbytes)
        shm_pairDis_real = np.ndarray(shape=pairDis_shape, dtype=pairDis_dtype, buffer=shm_pairDis.buf)
        shm_pairDis_real[:, :, :, :] = 0
        pairDis_All = [pairDis_shape, pairDis_dtype, shm_pairDis]
        #
        MS_Loss_p_shape = (num_class_all, num_instant_maxclass)
        MS_Loss_p_dtype = 'float64'  # 2 bt
        MS_Loss_p_nbytes = num_class_all * num_instant_maxclass *8
        shm_MS_Loss_p = smm.SharedMemory(size=MS_Loss_p_nbytes)
        shm_MS_Loss_p_real = np.ndarray(shape=MS_Loss_p_shape, dtype=MS_Loss_p_dtype, buffer=shm_MS_Loss_p.buf)
        shm_MS_Loss_p_real[:, :] = 0
        MS_Loss_p_All = [MS_Loss_p_shape, MS_Loss_p_dtype, shm_MS_Loss_p]
        #
        MS_Loss_n_shape = (num_class_all, num_instant_maxclass)
        MS_Loss_n_dtype = 'float64'  # 2 bt
        MS_Loss_n_nbytes = num_class_all * num_instant_maxclass *8
        shm_MS_Loss_n = smm.SharedMemory(size=MS_Loss_n_nbytes)
        shm_MS_Loss_n_real = np.ndarray(shape=MS_Loss_n_shape, dtype=MS_Loss_n_dtype, buffer=shm_MS_Loss_n.buf)
        shm_MS_Loss_n_real[:, :] = 0
        MS_Loss_n_All = [MS_Loss_n_shape, MS_Loss_n_dtype, shm_MS_Loss_n]
        cal_pairwise_distance_all(feature_all, label_all, num_instant_eachclass, pairDis_All)
        cal_MSLossArray_all(pairDis_All, MS_Loss_p_All,MS_Loss_n_All, num_instant_eachclass, alpha=alpha, beta=beta, base=base)
        for class_item in range(num_class_all):
            for item in range(num_instant_eachclass[class_item]):
                shm_MS_Loss_p_real[class_item,item] = math.log(1 + shm_MS_Loss_p_real[class_item,item]) / alpha
                shm_MS_Loss_n_real[class_item,item] = math.log(1 + shm_MS_Loss_n_real[class_item,item]) / beta
        WeightAll = np.zeros((num_class_all, num_instant_maxclass))
        for class_item in range(num_class_all):
            WeightAll[class_item,:num_instant_eachclass[class_item]]=1
        mu = lamb * 5
        Smax = S = 100
        T = 100
        printF=100
        lr = 1
        ActivaNum = 2
        WActive = np.zeros((num_class_all, num_instant_maxclass))
        rate = 0.9
        Wrate = np.zeros((num_class_all, num_instant_maxclass))
        Wratio_each = np.ones(num_class_all)
        first = True
        # np.save(os.path.join('Weight.npy'), WeightAll)
        while True:
            S = S - 1
            if S < 0: break
            np.random.seed(int(time.time()))
            orderClass = np.random.permutation(range(num_class_all))
            for itemClass in orderClass:
                Wratio_otherall = np.sum(Wratio_each) - Wratio_each[itemClass]
                Wratio_otherall = Wratio_otherall / (num_class_all - 1)
                for t in range(T):
                    orderInstant =  np.random.permutation(range(num_instant_eachclass[itemClass]))
                    for item in orderInstant:
                        if WActive[itemClass][item] > 0:
                            WActive[itemClass][item] = WActive[itemClass][item] - 1
                            continue
                        loss_a = cal_loss_a(shm_MS_Loss_p_real[itemClass,item], shm_MS_Loss_n_real[itemClass,item],WeightAll, num_instant_eachclass,
                                            itemClass,item)
                        loss_p = cal_loss_p(shm_MS_Loss_p_real,WeightAll, num_instant_eachclass, itemClass,item)
                        loss_n = cal_loss_n(shm_MS_Loss_n_real, WeightAll, num_instant_eachclass, itemClass)
                        g = loss_a + loss_p + loss_n
                        g=g/sum(num_instant_eachclass)
                        g = g - lamb + 2 * mu * (Wratio_each[itemClass] - Wratio_otherall)
                        g = lr * g
                        Wrate[itemClass][item] = rate * Wrate[itemClass][item] - g
                        temp = WeightAll[itemClass][item]
                        if  Wrate[itemClass][item]>0:
                            WeightAll[itemClass][item]=1
                            if temp == 1: WActive[itemClass][item] = ActivaNum
                        else:
                            WeightAll[itemClass][item]=0
                            if temp == 0: WActive[itemClass][item] = ActivaNum
                        Wratio_each[itemClass] += (WeightAll[itemClass][item] - temp) / num_instant_eachclass[itemClass]
            if (Smax - S) % printF == 0:
                if first:
                    WeightRatio = np.sum(Wratio_each) / len(Wratio_each)
                    if WeightRatio > highest:
                        lamb = lamb / np.power(high_ratio,high_num)
                        mu = mu / np.power(high_ratio,high_num)
                        high_num+=1
                        low_num=1
                        print("%3f get smaller" % (lamb))
                        S = Smax
                        WeightAll = np.zeros((num_class_all, num_instant_maxclass))
                        for class_item in range(num_class_all):
                            WeightAll[class_item, :num_instant_eachclass[class_item]] = 1
                        WActive = np.zeros((num_class_all, num_instant_maxclass))
                        Wrate = np.zeros((num_class_all, num_instant_maxclass))
                        Wratio_each = np.ones(num_class_all)
                    elif WeightRatio < lowest:
                        lamb = lamb * np.power(low_ratio,low_num)
                        mu = mu * np.power(low_ratio,low_num)
                        low_num+=1
                        high_num=1
                        print("%3f get bigger" % (lamb))
                        S = Smax
                        WeightAll = np.zeros((num_class_all, num_instant_maxclass))
                        for class_item in range(num_class_all):
                            WeightAll[class_item, :num_instant_eachclass[class_item]] = 1
                        WActive = np.zeros((num_class_all, num_instant_maxclass))
                        Wrate = np.zeros((num_class_all, num_instant_maxclass))
                        Wratio_each = np.ones(num_class_all)
                    else:
                        first = False
                        print("lamb: "+str(lamb))
                        print(Wratio_each)
                else:
                    print(Wratio_each)
        train_dataset=update_train_dataset(train_dataset,WeightAll,num_instant_eachclass)
        WeightAll_result=[]
        for class_only in range(num_class_all):
            WeightAll_result=np.concatenate((WeightAll_result,WeightAll[class_only,:num_instant_eachclass[class_only]]),axis=0)
        return train_dataset, lamb,WeightAll_result

def update_train_dataset(train_dataset, WeightAll,num_instant_eachclass):
    num_class=WeightAll.shape[0]
    real_img_paths=train_dataset.real_img_paths
    real_labels=train_dataset.real_labels
    img_paths=[]
    labels=[]
    num_before_class=0
    for i in range(num_class):
        if i>0:
            num_before_class=sum(num_instant_eachclass[:i])
        for j in range(num_instant_eachclass[i]):
            if real_labels[num_before_class + j] ==i:
                if WeightAll[i][j] > 0:
                    img_paths.append(real_img_paths[num_before_class + j])
                    labels.append(real_labels[num_before_class + j])
            else:
                print("error")
    train_dataset.img_paths=img_paths
    train_dataset.labels=np.array(labels)
    return train_dataset


def cal_loss_a(MS_Loss_p,MS_Loss_n,WeightAll, num_instant_eachclass, itemClass,item):
    weight_p=sum(WeightAll[itemClass])
    weight_n = sum(sum(WeightAll))-weight_p
    weight_p=weight_p-WeightAll[itemClass,item]
    num_p=num_instant_eachclass[itemClass]
    num_n=sum(num_instant_eachclass)-num_p
    num_p=num_p-1
    return weight_p/num_p*MS_Loss_p+weight_n/num_n*MS_Loss_n

def cal_loss_a_batch(MS_Loss_p,MS_Loss_n,WeightAll, num_instant_eachclass, itemClass,item,batch_size):
    weight_p=sum(WeightAll[itemClass])-WeightAll[itemClass,item]
    num_p=num_instant_eachclass[itemClass]-1
    weight_n=0
    list_m=[item for item in range(len(num_instant_eachclass)) if item!=itemClass]
    for batch in range(batch_size):
        class_n=random.sample(list_m,1)[0]
        instant_n=random.sample(list(range(num_instant_eachclass[class_n])),1)[0]
        weight_n+=WeightAll[class_n,instant_n]
    return weight_p/num_p*MS_Loss_p+weight_n/batch_size*MS_Loss_n

def cal_loss_p(MS_Loss_p,WeightAll, num_instant_eachclass, itemClass,item):
    num_p = num_instant_eachclass[itemClass]-1
    loss_p=0
    for p_instant in range(num_instant_eachclass[itemClass]):
        if p_instant==item: continue
        loss_p+=WeightAll[itemClass,p_instant]*MS_Loss_p[itemClass,p_instant]
    return loss_p/num_p

def cal_loss_n(MS_Loss_n, WeightAll, num_instant_eachclass, itemClass):
    num_n=sum(num_instant_eachclass)-num_instant_eachclass[itemClass]
    loss_n=0
    for n_class in range(len(num_instant_eachclass)):
        if n_class==itemClass: continue
        for n_instant in range(num_instant_eachclass[n_class]):
            loss_n+=WeightAll[n_class,n_instant]*MS_Loss_n[n_class,n_instant]
    return loss_n/num_n

def cal_loss_n_batch(MS_Loss_n, WeightAll, num_instant_eachclass, itemClass,batch_size):
    list_m=[item for item in range(len(num_instant_eachclass)) if item!=itemClass]
    loss_n = 0
    for batch in range(batch_size):
        class_n = random.sample(list_m, 1)[0]
        instant_n = random.sample(list(range(num_instant_eachclass[class_n])), 1)[0]
        loss_n+=WeightAll[class_n,instant_n]*MS_Loss_n[class_n,instant_n]
    return loss_n/batch_size

@njit
def njitlossapn(a,b,c):
    return a*b*c


def cal_object_value(WeightAll,TripletLossArray_All,num_instant_eachclass,lamb):
    (num_class_all, num_instant_maxclass,num_instant_maxclass,num_class_all, num_instant_maxclass)=TripletLossArray_All[0]
    Asy_result=[]
    pool = multiprocessing.Pool(processes=20)
    for i in range(20):
        mean = int(num_class_all / 20) + 1
        list = range(mean * i, min(num_class_all,mean * (i + 1)))
        Asy_result.append(pool.apply_async(AsyObject, (WeightAll, TripletLossArray_All,list,num_instant_eachclass)))
    pool.close()
    pool.join()
    object_value = 0
    object_index=0
    for item in Asy_result:
        object_value += item.get()[0]
        object_index += item.get()[1]

    object_value=object_value/object_index
    Weight_value=0
    Weight_index=0
    Weight_ratio=[]
    for itemClass in range(num_class_all):
        Weight_value_itemClass=0
        for item in range(num_instant_eachclass[itemClass]):
            Weight_value_itemClass+=WeightAll[itemClass][item]
            Weight_index+=1
        Weight_value+=Weight_value_itemClass
        Weight_ratio.append(Weight_value_itemClass/num_instant_eachclass[itemClass])
    Weight_value=Weight_value/Weight_index*lamb
    return [object_value-Weight_value,Weight_ratio]


def AsyObject(WeightAll, TripletLossArray_All,list,num_instant_eachclass):
    try:
        object_value=0
        object_index=0
        (num_class_all, num_instant_maxclass, num_instant_maxclass, num_class_all, num_instant_maxclass) = \
        TripletLossArray_All[0]
        TripletLossArray = np.ndarray(shape=TripletLossArray_All[0], dtype=TripletLossArray_All[1],
                                      buffer=TripletLossArray_All[2].buf)
        for a_class in list:
            if a_class >= num_class_all: continue
            for a_instant in range(num_instant_eachclass[a_class]):
                for p_instant in range(num_instant_eachclass[a_class]):
                    if p_instant == a_instant: continue
                    for n_class in range(num_class_all):
                        if n_class == a_class: continue
                        for n_instant in range(num_instant_eachclass[n_class]):
                            object_value+=njitObject(WeightAll[a_class][a_instant],WeightAll[a_class][p_instant],WeightAll[n_class][n_instant],np.float32(TripletLossArray[a_class][a_instant][p_instant][n_class][n_instant]))
                            object_index+=1
        return [object_value,object_index]
    except Exception as ex:
        print(str(ex))


@njit
def njitObject(a, b, c,d):
    return a*b*c*d