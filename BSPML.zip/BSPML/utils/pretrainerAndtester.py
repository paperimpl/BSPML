import os
import time

import torch
from torch.utils.data import DataLoader

from utils.preprocessor import Preprocessor
from utils.prerecall import recall


def trainer(epoch,device,train_loader,optimizer,model,mining_func,loss_func,optimizer_loss=None):
    #print('epoch: {}'.format(epoch))
    model.train()
    for batch_idx, (data, labels) in enumerate(train_loader):
        data, labels = data.to(device), labels.to(device)
        if optimizer_loss!=None:
            optimizer_loss.zero_grad()
        optimizer.zero_grad()
        embeddings = model(data)
        indices_tuple = mining_func(embeddings, labels)
        loss = loss_func(embeddings, labels, indices_tuple)
        loss.backward()
        optimizer.step()
        if optimizer_loss!=None:
            optimizer_loss.step()
        #if batch_idx % 100 == 0:
            #print("Epoch {} Iteration {}: Loss = {}".format(epoch, batch_idx, loss))
    return model
def tester(model,device,test_loader,test_labels,local,epoch,type):
    model.eval()
    with torch.no_grad():
        test_embeddings = torch.Tensor([]).cpu()
        for batch_idx, (data, labels) in enumerate(test_loader):
            data, labels = data.to(device), labels.to(device)
            embeddings = model(data)
            test_embeddings = torch.cat((test_embeddings, embeddings.cpu()), dim=0)
        test_embeddings = test_embeddings.cpu().detach().numpy()
        k=130
        recall_k=recall(k,test_embeddings, test_embeddings,test_labels, test_labels,True)

        print_content=("epoch {:.0f}: {:.3f}  {:.3f}  {:.3f}  {:.3f}  {:.3f}  {:.3f} {:.3f} {:.3f}"
              .format(epoch,recall_k[0],recall_k[1],recall_k[3],recall_k[7],recall_k[15],recall_k[31],recall_k[63],recall_k[127]))

        local[3]=local[3]+type+".txt"
        res_save(print_content,local)


def res_save(print_content,save_local):
    local=save_local[0]
    try:
        os.mkdir(local)
    except:
        pass
    local=local+'/'+save_local[1]
    try:
        os.mkdir(local)
    except:
        pass
    local = local + '/' + save_local[2]
    try:
        os.mkdir(local)
    except:
        pass
    local= local + '/' + save_local[3]
    with open(local, mode='a') as filename:
        filename.write(print_content)
        filename.write('\n')  # 换行
        filename.flush()
    print(print_content)