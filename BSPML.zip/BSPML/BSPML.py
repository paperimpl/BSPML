import copy
import time

from powerful_benchmarker.utils.dataset_utils import create_subset
from pytorch_metric_learning import losses, miners, distances, reducers, testers,samplers
from pytorch_metric_learning.utils.accuracy_calculator import AccuracyCalculator
from pytorch_metric_learning.utils.common_functions import *
from torch.backends import cudnn
from torch.utils.data import DataLoader
from torchvision import datasets
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
import numpy as np
from powerful_benchmarker.datasets import *

from utils.prenoise import noise
from utils.preprocessor import Preprocessor
from utils.presplit import split_dataset
from utils.pretrainerAndtester import trainer, tester
from utils.pretransformer import PreTransformer
import models

from utils.preweight_MS import UpdateW as complex
import os

def BSPML(dataset, device, gpu, batch_size, m,learn_rate,
          weight_decay,ratio, seed,epoch_all,epoch_each,lamb,m_f,lamb_max,highest,lowest):
    print(dataset.name + " : " + str(ratio) + " : BSPML")
    if gpu != None:
        os.environ["CUDA_VISIBLE_DEVICES"] = gpu
    train_dataset, test_dataset, val_dataset = split_dataset(dataset, 0.5)
    if ratio > 0:
        train_dataset = noise(train_dataset, ratio, seed)
    sampler = samplers.MPerClassSampler(labels=train_dataset.labels, m=m, batch_size=batch_size,
                                        length_before_new_iter=len(train_dataset.labels))
    train_loader = DataLoader(Preprocessor(train_dataset), batch_size=batch_size, sampler=sampler, drop_last=True)
    val_loader = DataLoader(Preprocessor(val_dataset), batch_size=batch_size, drop_last=False)
    test_loader = DataLoader(Preprocessor(test_dataset), batch_size=batch_size, drop_last=False)
    model = models.create('resnet50',  dropout=0.5, num_classes=512).to(device)
    optimizer = optim.SGD(model.parameters(), lr=learn_rate, weight_decay=weight_decay)
    distance = distances.CosineSimilarity()
    reducer = reducers.MeanReducer()
    alpha=2
    beta=50
    base=1
    loss_func = losses.MultiSimilarityLoss(distance=distance, reducer=reducer, alpha=alpha, beta=beta, base=base)
    mining_func = miners.MultiSimilarityMiner(distance=distance, epsilon=0.1)
    if ratio > 0:
        local = ["result", dataset.name + str(ratio), "BSPML", "time" + str(int(time.time()))]
    else:
        local = ["result", dataset.name, "BSPML", "time" + str(int(time.time()))]

    epoch = 0
    while epoch<epoch_all:
        epoch=epoch+1
        model.train()
        model = trainer(epoch, device, train_loader, optimizer, model, mining_func, loss_func)
        if (epoch) % 5 == 0:
            model.eval()
            with torch.no_grad():
                tester(model, device, test_loader, test_dataset.labels, copy.deepcopy(local), epoch,type="test")
                tester(model, device, val_loader, val_dataset.labels, copy.deepcopy(local), epoch,type="train")
        if (epoch) % epoch_each == 0:
            model.eval()
            with torch.no_grad():
                train_dataset, lamb, weightAll = complex(model, device, train_dataset, batch_size, lamb=lamb,
                                                         alpha=alpha, beta=beta, base=base, highest=highest,
                                                         lowest=lowest)
                lamb=min(lamb_max,lamb*m_f)
                highest=lowest=2
                sampler = samplers.MPerClassSampler(labels=train_dataset.labels, m=m, batch_size=batch_size,
                                                    length_before_new_iter=len(train_dataset.labels))
                train_loader = DataLoader(Preprocessor(train_dataset), batch_size=batch_size, sampler=sampler,
                                          drop_last=True)